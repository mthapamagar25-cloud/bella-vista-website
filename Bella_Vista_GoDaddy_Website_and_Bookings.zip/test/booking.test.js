'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const http=require('node:http');
const mysql=require('mysql2/promise');
const {databaseConfig}=require('../database');
const baseConfig=databaseConfig();
if(process.env.BV_TEST_MYSQL!=='1'||!['127.0.0.1','localhost'].includes(baseConfig.host))throw new Error('Tests require BV_TEST_MYSQL=1 and a disposable local MySQL server. Never run against GoDaddy.');
const crypto=require('node:crypto');
const {createApp,london,londonEpoch}=require('../server');

async function fixture(t,existingDatabase,beforeStart){
  const database=existingDatabase||'bv_test_'+crypto.randomBytes(10).toString('hex');
  const admin=await mysql.createConnection(baseConfig);
  if(!existingDatabase)await admin.query('CREATE DATABASE '+mysql.escapeId(database));
  if(beforeStart){await admin.query('USE '+mysql.escapeId(database));await beforeStart(admin);}
  const app=await createApp({database:{...baseConfig,database},password:'test-only-password-for-reservations',now:()=>Date.parse('2026-10-16T17:00:00Z'),production:false});
  const server=http.createServer(app.handler);await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
  const origin='http://127.0.0.1:'+server.address().port;let cookie='',csrf='',stopped=false;
  const stop=async()=>{if(!stopped){stopped=true;await new Promise(resolve=>server.close(resolve));await app.close();}};
  t.after(async()=>{await stop();try{if(!existingDatabase)await admin.query('DROP DATABASE '+mysql.escapeId(database));}finally{await admin.end();}});
  async function request(route,{method='GET',body,auth=true,headers={}}={}){
    const response=await fetch(origin+route,{method,headers:{'Content-Type':'application/json','X-BV-Request':'1',...(auth?{Cookie:cookie,'X-CSRF-Token':csrf}:{}),...headers},...(body===undefined?{}:{body:JSON.stringify(body)})});
    const raw=await response.text();let data;try{data=JSON.parse(raw);}catch{data=raw;}return{status:response.status,data,headers:response.headers};
  }
  async function login(){const r=await request('/api/login',{method:'POST',auth:false,body:{password:'test-only-password-for-reservations'}});assert.equal(r.status,200);cookie=r.headers.get('set-cookie').split(';')[0];csrf=r.data.csrf;}
  async function settings(patch){const r=await request('/api/admin/settings');return request('/api/admin/settings',{method:'PATCH',body:{...r.data,...patch}});}
  function payload(patch={}){return {requestKey:crypto.randomUUID(),token:crypto.randomBytes(32).toString('base64url'),date:'2026-11-03',time:'18:00',guests:2,name:'Test Guest',email:'guest@example.test',phone:'02070000000',notes:'A quiet table',acknowledged:true,...patch};}
  async function book(patch={}){const body=payload(patch),r=await request('/api/bookings',{method:'POST',auth:false,body});return{...r,body};}
  return{request,login,settings,book,payload,database,stop,app};
}

test('real request -> owner approval -> private status -> cancellation, with durable restart',async t=>{
  const f=await fixture(t);await f.login();assert.equal((await f.settings({accepting:true})).status,200);
  const b=await f.book();assert.equal(b.status,201);assert.equal(b.data.status,'pending');
  const list=await f.request('/api/admin/bookings?date=2026-11-03');assert.equal(list.data.bookings.length,1);assert.equal(list.data.bookings[0].name,'Test Guest');
  let updated=await f.request('/api/admin/bookings/'+b.data.id,{method:'PATCH',body:{status:'accepted',version:1}});assert.equal(updated.status,200);
  let status=await f.request('/api/status',{method:'POST',auth:false,body:{id:b.data.id,token:b.body.token}});assert.equal(status.data.status,'accepted');assert.equal(status.data.email,undefined);
  assert.equal((await f.request('/api/admin/bookings/'+b.data.id,{method:'PATCH',body:{status:'declined',version:1}})).status,409);
  await f.stop();const second=await fixture(t,f.database);await second.login();status=await second.request('/api/status',{method:'POST',auth:false,body:{id:b.data.id,token:b.body.token}});assert.equal(status.data.status,'accepted');
  status=await second.request('/api/status',{method:'POST',auth:false,body:{id:b.data.id,token:b.body.token,cancel:true}});assert.equal(status.data.status,'cancelled');
});
test('concurrent requests cannot overfill seats; cancellation releases capacity and retries are idempotent',async t=>{
  const f=await fixture(t);await f.login();await f.settings({accepting:true,capacity:4,maxParty:4});
  const results=await Promise.all(Array.from({length:5},()=>f.book({guests:2})));assert.equal(results.filter(r=>r.status===201).length,2);assert.equal(results.filter(r=>r.status===409).length,3);
  const b=results.find(r=>r.status===201);const retry=await f.request('/api/bookings',{method:'POST',auth:false,body:b.body});assert.equal(retry.status,201);assert.equal(retry.data.id,b.data.id);
  await f.request('/api/status',{method:'POST',auth:false,body:{id:b.data.id,token:b.body.token,cancel:true}});assert.equal((await f.book({guests:2})).status,201);
  assert.equal((await f.book({time:'20:00',guests:4})).status,201);
});
test('availability enforces opening date, arbitrary time rejection, closed windows and global pause',async t=>{
  const f=await fixture(t);await f.login();const initial=await f.request('/api/config');assert.equal(initial.data.accepting,false);assert.equal((await f.book()).status,409);await f.settings({accepting:true});
  assert.equal((await f.book({date:'2026-11-02'})).status,409);assert.equal((await f.book({time:'18:17'})).status,409);assert.equal((await f.book({date:'2026-02-30'})).status,400);assert.equal((await f.book({time:'22:00'})).status,409);
  const closed=await f.request('/api/admin/closures',{method:'POST',body:{date:'2026-11-03',start:'18:00',end:'20:00',allDay:false}});assert.equal(closed.status,201);
  const slots=await f.request('/api/availability?date=2026-11-03&guests=2');assert.ok(!slots.data.slots.includes('18:00'));assert.ok(slots.data.slots.includes('20:00'));assert.equal((await f.book()).status,409);
  await f.request('/api/admin/closures/'+closed.data.id,{method:'DELETE'});const booking=await f.book();assert.equal(booking.status,201);
  await f.settings({accepting:false});assert.equal((await f.book()).status,409);assert.equal((await f.request('/api/admin/bookings?date=2026-11-03')).data.bookings.length,1);
  await f.settings({accepting:true});assert.equal((await f.book()).status,201);
  const all=await f.request('/api/admin/closures',{method:'POST',body:{date:'2026-11-04',allDay:true}});assert.equal(all.status,201);assert.equal((await f.request('/api/availability?date=2026-11-04&guests=2')).data.slots.length,0);
});
test('authentication, CSRF, origin, static-file restrictions and private tokens protect data',async t=>{
  const f=await fixture(t);
  for(const route of ['/api/admin/bookings?date=2026-11-03','/api/admin/export','/api/admin/backup'])assert.equal((await f.request(route,{auth:false})).status,401);
  for(const route of ['/server.js','/package.json','/data/bookings.sqlite','/.env'])assert.equal((await f.request(route)).status,404);
  assert.equal((await f.request('/api/login',{method:'POST',body:{password:'wrong'}})).status,401);
  await f.login();await f.settings({accepting:true});const settings=await f.request('/api/admin/settings');
  assert.equal((await f.request('/api/admin/settings',{method:'PATCH',body:settings.data,headers:{'X-CSRF-Token':''}})).status,403);
  assert.equal((await f.request('/api/admin/settings',{method:'PATCH',body:settings.data,headers:{Origin:'https://attacker.invalid'}})).status,403);
  const b=await f.book();assert.equal((await f.request('/api/status',{method:'POST',auth:false,body:{id:b.data.id,token:'incorrect'}})).status,404);
  assert.equal((await f.request('/api/bookings',{method:'POST',auth:false,body:f.payload({website:'spam'})})).status,400);
});
test('export defuses spreadsheet formulas and safe backup omits sessions and credentials',async t=>{
  const f=await fixture(t);await f.login();await f.settings({accepting:true});await f.book({name:'=HYPERLINK("bad")',notes:'<script>alert(1)</script>'});
  const csv=await f.request('/api/admin/export');assert.equal(csv.status,200);assert.match(csv.data,/'=HYPERLINK/);
  const backup=await f.request('/api/admin/backup');assert.equal(backup.data.bookings.length,1);assert.equal(backup.data.sessions,undefined);assert.equal(backup.data.password,undefined);
});
test('overlapping occupancy considers the peak, not the sum of sequential sittings',async t=>{
  const f=await fixture(t);await f.login();await f.settings({accepting:true,capacity:4,maxParty:4,duration:60});
  assert.equal((await f.book({time:'18:00',guests:2})).status,201);assert.equal((await f.book({time:'19:00',guests:2})).status,201);
  await f.settings({duration:120});assert.equal((await f.book({time:'18:00',guests:2})).status,201);assert.equal((await f.book({time:'18:30',guests:1})).status,409);
});
test('London calendar and elapsed lead time use British Summer Time correctly',()=>{
  assert.deepEqual(london(Date.parse('2026-10-16T23:30:00Z')),{date:'2026-10-17',minute:30});
  assert.equal(londonEpoch('2027-03-28',720),Date.parse('2027-03-28T11:00:00Z'));
  assert.equal(londonEpoch('2026-11-03',720),Date.parse('2026-11-03T12:00:00Z'));
});

test('database configuration fails closed without credentials',()=>{
  assert.throws(()=>databaseConfig({host:''}),/DB_HOST/);
  assert.throws(()=>databaseConfig({password:''}),/DB_PASSWORD/);
  assert.throws(()=>databaseConfig({port:'invalid'}),/DB_PORT/);
});

test('two app instances share capacity, closures, settings and idempotent requests',async t=>{
  const first=await fixture(t);await first.login();await first.settings({accepting:true,capacity:4,maxParty:4});
  const second=await fixture(t,first.database);await second.login();
  const bookings=await Promise.all(Array.from({length:8},(_,i)=>(i%2?first:second).book({guests:2})));
  assert.equal(bookings.filter(b=>b.status===201).length,2);
  assert.equal(bookings.filter(b=>b.status===409).length,6);
  const b=bookings.find(b=>b.status===201);
  const retry=await second.request('/api/bookings',{method:'POST',auth:false,body:b.body});
  assert.equal(retry.status,201);assert.equal(retry.data.id,b.data.id);
  const list=await second.request('/api/admin/bookings?date=2026-11-03');assert.equal(list.data.bookings.length,2);
  await first.request('/api/admin/closures',{method:'POST',body:{date:'2026-11-04',allDay:true}});
  assert.equal((await second.book({date:'2026-11-04'})).status,409);
  await first.settings({accepting:false});assert.equal((await second.book({date:'2026-11-05'})).status,409);
});

test('failed transactions roll back booking and settings changes together',async t=>{
  const f=await fixture(t);await f.login();
  const before=(await f.request('/api/admin/settings')).data;
  await assert.rejects(f.app.db.transaction(async()=>{
    await f.app.db.prepare('UPDATE bv_settings SET version=version+1 WHERE id=1').run();
    throw new Error('simulated failure');
  }),/simulated failure/);
  assert.equal((await f.request('/api/admin/settings')).data.version,before.version);
});

const legacyDDL=`CREATE TABLE bv_bookings (
  id VARCHAR(32) NOT NULL PRIMARY KEY,payload LONGTEXT NOT NULL,status VARCHAR(20) NOT NULL,
  created VARCHAR(30) NOT NULL,updated VARCHAR(30) NOT NULL,
  email_state VARCHAR(255) NOT NULL DEFAULT 'Not sent',note TEXT NOT NULL
) ENGINE=InnoDB`;

test('the exact empty legacy payload table is preserved while booking, approval and cancellation work',async t=>{
  const f=await fixture(t,undefined,async connection=>{await connection.query(legacyDDL);});
  assert.equal(f.app.db.bookingsTable,'bv_reservations');await f.login();
  let list=await f.request('/api/admin/bookings?date=2026-11-03');assert.equal(list.status,200);assert.deepEqual(list.data.bookings,[]);
  assert.equal((await f.settings({accepting:true})).status,200);
  const b=await f.book();assert.equal(b.status,201);
  list=await f.request('/api/admin/bookings?view=pending');assert.equal(list.status,200);assert.equal(list.data.pending,1);
  assert.equal((await f.request('/api/admin/bookings/'+b.data.id,{method:'PATCH',body:{status:'accepted',version:1}})).status,200);
  assert.equal((await f.request('/api/admin/export')).status,200);
  assert.equal((await f.request('/api/admin/backup')).data.bookings.length,1);
  assert.deepEqual((await f.app.db.prepare('SHOW COLUMNS FROM bv_bookings').all()).map(c=>c.Field),['id','payload','status','created','updated','email_state','note']);
  assert.equal((await f.app.db.prepare('SELECT COUNT(*) AS n FROM bv_bookings').get()).n,0);
  await f.stop();const second=await fixture(t,f.database);await second.login();
  const status=await second.request('/api/status',{method:'POST',auth:false,body:{id:b.data.id,token:b.body.token}});assert.equal(status.data.status,'accepted');
  assert.equal((await second.request('/api/status',{method:'POST',auth:false,body:{id:b.data.id,token:b.body.token,cancel:true}})).data.status,'cancelled');
});

test('a compatible existing v1.1.0 booking table keeps its bookings and capacity',async t=>{
  const f=await fixture(t);await f.login();await f.settings({accepting:true,capacity:2,maxParty:2});
  const b=await f.book();assert.equal(b.status,201);
  await f.app.db.prepare('RENAME TABLE bv_reservations TO bv_bookings').run();await f.stop();
  const second=await fixture(t,f.database);assert.equal(second.app.db.bookingsTable,'bv_bookings');await second.login();
  const list=await second.request('/api/admin/bookings?date=2026-11-03');assert.equal(list.data.bookings[0].id,b.data.id);
  assert.equal((await second.book()).status,409);
});

test('populated incompatible legacy data is preserved and blocks starting an empty replacement',async t=>{
  const f=await fixture(t);await f.app.db.prepare(legacyDDL).run();
  await f.app.db.prepare("INSERT INTO bv_bookings(id,payload,status,created,updated,note) VALUES('legacy-test','{\"keep\":true}','pending','old','old','preserve this')").run();
  await assert.rejects(createApp({database:{...baseConfig,database:f.database},password:'test-only-password-for-reservations',production:false}),/Export and migrate/);
  const row=await f.app.db.prepare('SELECT * FROM bv_bookings').get();assert.equal(row.note,'preserve this');assert.equal(row.payload,'{"keep":true}');
});

test('an incompatible auxiliary table produces a specific startup message',async t=>{
  const f=await fixture(t);await f.app.db.prepare('ALTER TABLE bv_closures DROP COLUMN reason').run();
  await assert.rejects(createApp({database:{...baseConfig,database:f.database},password:'test-only-password-for-reservations',production:false}),/bv_closures is missing columns: reason/);
});
